import time
from machine import Pin, UART
import my_oled
import uasyncio as asyncio

# initialize a new UART class
uart = UART(2, 9600,tx=37,rx=38)
# run the init method with more details including baudrate and parity
uart.init(9600, bits=8, parity=None, stop=1) 
# define pin 2 as an output with name led. (Pin 2 is connected to the ESP32-WROOM dev board's onboard blue LED)
led = Pin(2,Pin.OUT)

MAX_MESSAGE_LEN=64
team = [b'H',b'S',b'B',b'G']
id = b'H'
broadcast = b'X'

# Initialize buttons on IO4, IO5, and IO6
p6 = Pin(6, Pin.IN, Pin.PULL_UP)  # Button for toggling screens
p4 = Pin(4, Pin.IN, Pin.PULL_UP)  # Button to move rectangle up
p5 = Pin(5, Pin.IN, Pin.PULL_UP)  # Button to move rectangle down

# Initialize state variables
state = 0  # 0 for "test" screen, 1 for "something else" screen
previous_button_state = 1  # Button is not pressed initially

# Initialize rectangle position
rect_y = 0  # Initial vertical position of the rectangle
rect_x = 0  # Fixed horizontal position of the rectangle
rect_width = 63
rect_height = 7

# Initialize previous button states for p4 and p5
previous_p4_state = 1
previous_p5_state = 1

# Initialize selected planet variable
selected_planet = None

# Initialize selected option variable for secondary screen
selected_option = None  # None when no option is selected

# Initialize additional state variables
secondary_screen = False  # False for planet screen, True for "Direct Drive" and "Graphing" screen

# Initialize additional state variables for Direct Drive navigation
direct_drive_mode = None  # None when not in "Left" or "Right" selection
selected_speed = None  # None when not selecting a speed

# Planet information dictionary
planet_info = {
    "Mercury": "Closest planet to the earth yeah yeah.",  # Adjusted text to fit the screen width
    "Venus": "Hottest planet.",
    "The Moon": "Earth's satellite.",
    "Mars": "The Red Planet.",
    "Jupiter": "Largest planet.",
    "Saturn": "Has rings.",
    "Neptune": "Farthest planet.",
    "Pluto": "Dwarf planet."
}

# Initialize global variable for graphing content
graphing_content = "Graphing Mode displays system performance over time."

def send_message(message):
    print('ESP: send message')
    print(message)
    # send_queue.append(message)

def handle_message(message):
    try:
        # Attempt to decode as UTF-8 while preserving non-decodable bytes
        my_string = message.decode('utf-8', errors='replace')  # Replace undecodable bytes with placeholders
        print('ESP: handling my message (decoded with placeholders):', my_string)
    except Exception as e:
        # If decoding fails entirely, preserve the original message
        print('ESP: handling my message (raw):', message)
        my_string = message

    # If the fourth character is not the ID, forward the message
    if len(message) >= 4 and message[3:4] != id:
        print('ESP: Forwarding message to another system:', message)
        uart.write(message)  # Send the original message


async def process_rx():

    # stream = []
    stream = b''
    message = b''
    send_queue = []
    receiving_message=False
    global graphing_content  # Ensure this variable is accessible globally

    while True:
        # read one byte
        c = uart.read(1)
        # if c is not empty:
        if c is not None:

            stream += c
            try:
                if stream[-2:] == b'AZ':
                    message = stream[-2:-1]
                    receiving_message = True
            except IndexError:
                pass
            try:
                if stream[-2:] == b'YB':
                    message += stream[-1:]
                    print('DEBUG - Full Message:', message)
                    if message[3:4] == id:
                        # Simply store the full message
                        graphing_content = message.decode()
                        print('DEBUG - Updated graphing_content:', graphing_content)
                    else:
                        handle_message(message)
            
                    if message[3:4] == broadcast:
                        handle_message(message)
                    stream = b''
                    receiving_message = False
                    message = b''
            except IndexError:
                print('ESP: IndexError while processing message')
                pass
            
            if receiving_message:
                message += c
                print('ESP: Receiving message (raw bytes):', message)

                if len(message) == 3:
                    if not (message[2:3] in team):
                        print('ESP: sender not in team')
                    else:
                        print('ESP: sender in team')

                    if message[2:3] == id:
                        print('ESP: Message contains own ID as receiver, not handling')
                        receiving_message = False
                        message = b''

                if len(message) == 4:
                    if not (message[3:4] in team):
                        print('ESP: receiver not in team')
                    else:
                        print('ESP: receiver in team')

                    if message[3:4] != broadcast:
                        print('ESP: receiver not in broadcast')
                    else:
                        print('ESP: receiver is in broadcast')

                if len(message) > MAX_MESSAGE_LEN:
                    receiving_message = False
                    print('ESP: Message too long, aborting')
                    message = b''

        await asyncio.sleep_ms(10)    
 

def read_button(pin):
    """Reads the current state of a button."""
    return pin.value()


def toggle_state(current_state):
    """Toggles the state between 0 and 1."""
    return 1 - current_state


async def debounce():
    """Adds a small delay to debounce the button."""
    await asyncio.sleep(0.1)


async def update_display(current_state, x, y):
    """Updates the OLED display based on the current state and rectangle position."""
    my_oled.oled.fill(0)  # Clear the OLED display
    if current_state == 0 and not secondary_screen:  # Planet screen
        my_oled.print_text("Mercury", 0, 0)
        my_oled.print_text("Venus", 0, 8)
        my_oled.print_text("The Moon", 0, 16)
        my_oled.print_text("Mars", 0, 24)
        my_oled.print_text("Jupiter", 0, 32)
        my_oled.print_text("Saturn", 0, 40)
        my_oled.print_text("Neptune", 0, 48)
        my_oled.print_text("Pluto", 0, 56)
    elif current_state == 1 or secondary_screen:  # Secondary screen
        my_oled.print_text("Direct Drive", 0, 0)
        my_oled.print_text("Graphing", 0, 8)

    # Adjust rectangle width based on text length
    local_width = rect_width
    if current_state == 1 or secondary_screen:
        if y == 0:  # Direct Drive option
            local_width = 100 # Increased width to fit "Direct Drive"
        else:
            local_width = rect_width

    # Draw the rectangle outline with dynamic width
    my_oled.oled.rect(x - 1, y - 1, local_width + 2, rect_height + 2, 1)
    my_oled.oled.show()


def wrap_text(text, max_chars_per_line):
    """Wraps a string into lines of a specified maximum length while preserving spaces."""
    # Split by spaces but preserve them
    words = text.replace(' ', '@ @').split('@')  # @ is temporary marker for spaces
    words = [w for w in words if w]  # Remove empty strings
    
    lines = []
    current_line = ""

    for word in words:
        # Test adding word with proper spacing
        test_line = current_line + word
        if len(current_line) > 0 and word != ' ':
            test_line = current_line + " " + word
            
        if len(test_line) <= max_chars_per_line:
            current_line = test_line
        else:
            if current_line:
                lines.append(current_line)
            current_line = word

    if current_line:
        lines.append(current_line)

    return lines


async def display_planet_info(planet):
    """Displays the information screen for the selected planet."""
    # Define the UART messages for each planet
    planet_messages = {
        "Mercury": b"AZHB03YB",
        "Venus": b"AZHB03YB",
        "The Moon": b"AZHB03YB",
        "Mars": b"AZHB05YB",
        "Jupiter": b"AZHB05YB",
        "Saturn": b"AZHB05YB",
        "Neptune": b"AZHB08YB",
        "Pluto": b"AZHB08YB",
    }

    # Send the UART message for the selected planet
    if planet in planet_messages:
        uart.write(planet_messages[planet])  # Send the message over UART
        print(f"UART Message Sent: {planet_messages[planet].decode()}")

    while True:
        my_oled.oled.fill(0)  # Clear the OLED display
        my_oled.print_text(f"{planet} Info", 0, 0)  # Display the planet name as the title

        # Wrap and display the planet information
        max_chars_per_line = 16  # Adjusted to fit the screen width
        info_lines = wrap_text(planet_info.get(planet, "No information available."), max_chars_per_line)
        for i, line in enumerate(info_lines):
            my_oled.print_text(line, 0, 16 + (i * 8))  # Display each line with 8-pixel spacing

        my_oled.print_text("Back", 0, 56)  # Back button
        my_oled.oled.rect(0, 55, 30, 9, 1)  # Outline for the back button
        my_oled.oled.show()

        # Add a delay to wait for the next input
        await asyncio.sleep(0.2)

        # Wait for the "Back" button to be pressed
        global previous_button_state
        current_button_state = read_button(p6)
        if previous_button_state == 1 and current_button_state == 0:  # Detect falling edge
            previous_button_state = current_button_state  # Update the previous state
            break  # Exit the loop when "Back" is pressed
        previous_button_state = current_button_state
        await debounce()


async def display_secondary_screen(option):
    """Displays the screen for the selected secondary option."""
    global previous_button_state, selected_option, graphing_content

    while True:
        my_oled.oled.fill(0)  # Clear the OLED display

        # Display wrapped content for the selected option
        max_chars_per_line = 16  # Adjusted to fit the screen width
        if option == "Direct Drive":
            content = "Direct Drive Mode allows manual control of the system."
        elif option == "Graphing":
            content = graphing_content  # Use the updated graphing content

        # Ensure content is not empty
        if not content:
            content = "No Data"

        info_lines = wrap_text(content, max_chars_per_line)
        for i, line in enumerate(info_lines):
            my_oled.print_text(line, 0, 16 + (i * 8))  # Display each line with 8-pixel spacing

        my_oled.print_text("Back", 0, 56)  # Back button
        my_oled.oled.rect(0, 55, 30, 9, 1)  # Outline for the back button
        my_oled.oled.show()

        # Add a delay to wait for the next input
        await asyncio.sleep(0.2)

        # Wait for the "Back" button to be pressed
        current_button_state = read_button(p6)
        if previous_button_state == 1 and current_button_state == 0:  # Detect falling edge
            selected_option = None  # Reset the selected option to return to the previous screen
            break  # Exit the loop when "Back" is pressed
        previous_button_state = current_button_state
        await debounce()

def read_distance_sensor():
    """Simulates reading a value from a distance sensor. Replace with actual sensor logic."""
    # Replace this with actual sensor reading logic
    import random
    return random.randint(10, 100)  # Simulate a distance value between 10 and 100


async def display_direct_drive_menu():
    """Displays the Direct Drive menu with Left and Right options."""
    global previous_button_state, previous_p4_state, previous_p5_state, rect_y, selected_option, direct_drive_mode

    valid_positions = [0, 8, 56]  # Valid positions for the rectangle (Left, Right, Back)

    while True:
        my_oled.oled.fill(0)  # Clear the OLED display
        my_oled.print_text("Left", 0, 0)
        my_oled.print_text("Right", 0, 8)
        my_oled.print_text("Back", 0, 56)  # Back button

        # Draw the rectangle outline over the current selection
        my_oled.oled.rect(rect_x - 1, rect_y - 1, rect_width + 2, rect_height + 2, 1)
        my_oled.oled.show()

        # Add a delay to wait for the next input
        await asyncio.sleep(0.2)

        # Read the current states of the buttons
        current_button_state = read_button(p6)
        current_p4_state = read_button(p4)
        current_p5_state = read_button(p5)

        # Handle "Back" button press
        if previous_button_state == 1 and current_button_state == 0:  # Detect falling edge
            if rect_y == 56:  # "Back" selected
                selected_option = None  # Reset the selected option
                rect_y = 8  # Set to Graphing position when going back
                break  # Exit the loop when "Back" is pressed
            elif rect_y == 0:  # "Left" selected
                direct_drive_mode = "Left"
                await display_speed_selection()  # Switch to speed selection screen
            elif rect_y == 8:  # "Right" selected
                direct_drive_mode = "Right"
                await display_speed_selection()  # Switch to speed selection screen

        # Handle rectangle movement down (p4 button)
        if previous_p4_state == 1 and current_p4_state == 0:
            current_index = valid_positions.index(rect_y)
            rect_y = valid_positions[min(current_index + 1, len(valid_positions) - 1)]  # Move to the next valid position
            previous_p4_state = current_p4_state

        # Handle rectangle movement up (p5 button)
        if previous_p5_state == 1 and current_p5_state == 0:
            current_index = valid_positions.index(rect_y)
            rect_y = valid_positions[max(current_index - 1, 0)]  # Move to the previous valid position
            previous_p5_state = current_p5_state

        # Update previous button states
        previous_button_state = current_button_state
        previous_p4_state = current_p4_state
        previous_p5_state = current_p5_state

        # Debounce the buttons
        await debounce()


async def display_speed_selection():
    """Displays the speed selection menu."""
    global previous_button_state, previous_p4_state, previous_p5_state, rect_y, direct_drive_mode, selected_speed

    valid_positions = [0, 8, 16, 24, 56]  # Valid positions for the rectangle (Speeds and Back)
    speeds = ["Speed 1", "Speed 2", "Speed 3", "Speed 4"]
    
    # Define speed messages based on direction
    speed_messages = {
        "Left": {
            0: b"AZHB13YB",  # Speed 1 Left
            1: b"AZHB13YB",  # Speed 2 Left
            2: b"AZHB15YB",  # Speed 3 Left
            3: b"AZHB18YB"   # Speed 4 Left
        },
        "Right": {
            0: b"AZHB03YB",  # Speed 1 Right
            1: b"AZHB03YB",  # Speed 2 Right
            2: b"AZHB05YB",  # Speed 3 Right
            3: b"AZHB08YB"   # Speed 4 Right
        }
    }

    while True:
        my_oled.oled.fill(0)  # Clear the OLED display
        for i, speed in enumerate(speeds):
            my_oled.print_text(speed, 0, i * 8)  # Display each speed option
        my_oled.print_text("Back", 0, 56)  # Back button

        # Draw the rectangle outline over the current selection
        my_oled.oled.rect(rect_x - 1, rect_y - 1, rect_width + 2, rect_height + 2, 1)
        my_oled.oled.show()

        # Add a delay to wait for the next input
        await asyncio.sleep(0.2)

        # Read the current states of the buttons
        current_button_state = read_button(p6)
        current_p4_state = read_button(p4)
        current_p5_state = read_button(p5)

        # Handle "Back" button press or speed selection
        if previous_button_state == 1 and current_button_state == 0:  # Detect falling edge
            if rect_y == 56:  # "Back" selected
                direct_drive_mode = None
                selected_speed = None
                rect_y = 8  # Set to Graphing position when going back
                break
            elif rect_y < 32:  # Speed selected (positions 0, 8, 16, 24)
                speed_index = rect_y // 8
                if direct_drive_mode in speed_messages:
                    message = speed_messages[direct_drive_mode][speed_index]
                    uart.write(message)
                    print(f"UART Message Sent: {message}")
                    selected_speed = speed_index  # Store the selected speed

        # Handle rectangle movement down (p4 button)
        if previous_p4_state == 1 and current_p4_state == 0:
            current_index = valid_positions.index(rect_y)
            rect_y = valid_positions[min(current_index + 1, len(valid_positions) - 1)]  # Move to the next valid position
            previous_p4_state = current_p4_state

        # Handle rectangle movement up (p5 button)
        if previous_p5_state == 1 and current_p5_state == 0:
            current_index = valid_positions.index(rect_y)
            rect_y = valid_positions[max(current_index - 1, 0)]  # Move to the previous valid position
            previous_p5_state = current_p5_state

        # Update previous button states
        previous_button_state = current_button_state
        previous_p4_state = current_p4_state
        previous_p5_state = current_p5_state

        # Debounce the buttons
        await debounce()


async def main_loop():
    global state, rect_y, rect_x, selected_planet, selected_option, secondary_screen
    global direct_drive_mode, selected_speed, previous_button_state, previous_p4_state, previous_p5_state

    while True:
        # Read the current states of the buttons
        current_button_state = read_button(p6)
        current_p4_state = read_button(p4)
        current_p5_state = read_button(p5)

        if selected_planet is None and selected_option is None:  # Home screen logic
            # Detect button press for p6 (falling edge) to select a planet
            if previous_button_state == 1 and current_button_state == 0:
                if state == 0 and not secondary_screen:  # Only allow selection on the planet screen
                    planets = ["Mercury", "Venus", "The Moon", "Mars", "Jupiter", "Saturn", "Neptune", "Pluto"]
                    selected_planet = planets[rect_y // 8]  # Determine selected planet based on rectangle position
                    await display_planet_info(selected_planet)  # Switch to the planet info screen
                    selected_planet = None  # Reset selected planet only after returning from info screen
                    await asyncio.sleep(0.2)  # Add a delay to wait for the next input
                    continue  # Skip the rest of the loop to avoid flashing

                elif secondary_screen:  # Secondary screen logic
                    options = ["Direct Drive", "Graphing"]
                    selected_option = options[rect_y // 8]  # Determine selected option based on rectangle position
                    if selected_option == "Direct Drive":
                        await display_direct_drive_menu()  # Switch to Direct Drive menu
                    elif selected_option == "Graphing":
                        await display_secondary_screen(selected_option)  # Switch to Graphing screen
                    await asyncio.sleep(0.2)  # Add a delay to wait for the next input

            # Detect button press for p4 (falling edge) to move rectangle down
            if previous_p4_state == 1 and current_p4_state == 0:
                if not secondary_screen:
                    if rect_y == 56:  # At the bottom of the planet screen
                        secondary_screen = True  # Switch to the secondary screen
                        rect_y = 0  # Reset rectangle position
                    else:
                        rect_y = min(64 - rect_height, rect_y + 8)  # Move rectangle down
                else:
                    rect_y = min(8, rect_y + 8)  # Move rectangle down on the secondary screen

            # Detect button press for p5 (falling edge) to move rectangle up
            if previous_p5_state == 1 and current_p5_state == 0:
                if secondary_screen:
                    if rect_y == 0:  # At the top of the secondary screen
                        secondary_screen = False  # Switch back to the planet screen
                        rect_y = 56  # Reset rectangle position
                    else:
                        rect_y = max(0, rect_y - 8)  # Move rectangle up
                else:
                    rect_y = max(0, rect_y - 8)  # Move rectangle up on the planet screen

            # Update the OLED display
            await update_display(state, rect_x, rect_y)

        elif selected_option is not None:  # Secondary option screen logic
            if selected_option == "Direct Drive" and direct_drive_mode is None and selected_speed is None:
                await display_direct_drive_menu()

            elif selected_option == "Graphing":
                await display_secondary_screen(selected_option)

            # Detect button press for p6 (falling edge) to go back to the secondary screen
            if previous_button_state == 1 and current_button_state == 0:
                selected_option = None  # Deselect the option and return to the secondary screen
                await update_display(state, rect_x, rect_y)  # Update the secondary screen display

        # Update previous button states
        previous_button_state = current_button_state
        previous_p4_state = current_p4_state
        previous_p5_state = current_p5_state

        # Debounce the buttons
        await debounce()

# Run the main loop and schedule the heartbeat and process_rx tasks
async def main():
    asyncio.create_task(process_rx())  # Schedule the process_rx coroutine
    await main_loop()  # Run the main loop

# Run the main function
asyncio.run(main())