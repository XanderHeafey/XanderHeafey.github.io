# boot.py -- run on boot-up
import time
time.sleep(.1)